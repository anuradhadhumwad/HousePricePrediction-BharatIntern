# bharat-intern-t1
BHARAT INTERN - Task 1, House Price Prediction using Linear Regression
Bharat Intern Machine Learning
